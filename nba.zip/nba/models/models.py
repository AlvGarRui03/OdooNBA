# -*- coding: utf-8 -*-

from odoo import models, fields, api
from dateutil.relativedelta import *
from datetime import date


class jugador(models.Model):
    _name = 'nba.jugador'
    _description = 'Jugador'

    name = fields.Char('Codigo jugador',required=True)
    nombre = fields.Char(string='Jugador',required=True)
    apellidos = fields.Char(string='Apellidos Jugador',required=True)
    fecha_nacimiento = fields.Date(string='Fecha de naciemiento',required=True)
    anios = fields.Integer("Años",compute="_get_anios")
    #relaciones
    equipo_jugador_id = fields.Many2one('nba.equipo',string='Equipo')

    @api.depends('fecha_nacimiento')
    def _get_anios(self):
        for jugador in self:
            hoy = date.today()
            jugador.anios = relativedelta(hoy,jugador.fecha_nacimiento).years


class presidente(models.Model):
    _name = 'nba.presidente'
    _description = 'Presidente'

    name = fields.Char('Codigo presidente',required=True)
    nombre = fields.Char(string='Presidente',required=True)
    apellidos = fields.Char(string='Apellidos Presidente',required=True)
    patrimonio = fields.Integer('Patrimonio',required=True)
    #relaciones
    equipo_presidente_id = fields.Many2one('nba.equipo',string='Equipo')


class patrocinador(models.Model):
    _name = 'nba.patrocinador'
    _description = 'Patrocinador'

    name = fields.Char('Codigo Patrocinador', required=True)
    patrocinador = fields.Char(string='Patrocinador', required=True)
    pago_patrocinio = fields.Integer('Pago', required=True)
    #relaciones
    equipo_patrocinador_ids = fields.Many2many('nba.equipo',string='Equipo')


class equipo(models.Model):
    _name = 'nba.equipo'
    _description = 'Equipo'

    name = fields.Char('Codigo Equipo',required=True)
    nombre = fields.Char(string='Equipo',required=True)
    ciudad = fields.Char(string='Ciudad',required=True)
    estadio = fields.Char(string='Estadio',required=True)
    #relaciones
    jugadores_id = fields.One2many('nba.jugador','equipo_jugador_id',string='Jugador')
    presidentes_id = fields.One2many('nba.presidente','equipo_presidente_id',string='Presidente')
    patrocinadores_ids = fields.Many2many('nba.patrocinador','equipo_patrocinador_ids',string='Equipo')
